@extends('layouts.main')

@section('content')
<div class="page-heading">
    <div class="page-title mb-4">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Daftar Surat Keputusan Tim Kerja</h3>
                <p class="text-subtitle text-muted">Daftar Surat Keputusan Pembentukan Tim Kerja Pengkajian Kebutuhan Pascabencana</p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <div class="float-end">
                    <a href="{{ route('forms.form2.index') }}" class="btn btn-primary">
                        <i class="bi bi-plus"></i> Tambah Surat Keputusan Baru
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    @if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
    @endif
    
    @if(session('error'))
    <div class="alert alert-danger">
        {{ session('error') }}
    </div>
    @endif
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-lg" id="tabelKeputusan">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nomor Surat</th>
                            <th>Lokasi</th>
                            <th>Bencana</th>
                            <th>Tanggal Ditetapkan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($keputusan as $index => $data)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $data->nomor_surat }}</td>
                            <td>{{ $data->lokasi }}</td>
                            <td>{{ $data->nama_bencana }}</td>
                            <td>{{ \Carbon\Carbon::parse($data->tanggal_ditetapkan)->format('d F Y') }}</td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="{{ route('forms.form2.show', $data->id) }}" class="btn btn-sm btn-primary" title="Detail">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="{{ route('forms.form2.edit', $data->id) }}" class="btn btn-sm btn-warning" title="Edit">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a href="{{ route('forms.form2.preview-pdf', $data->id) }}" class="btn btn-sm btn-info" target="_blank" title="Pratinjau PDF">
                                        <i class="bi bi-file-earmark-pdf"></i>
                                    </a>
                                    <a href="{{ route('forms.form2.pdf', $data->id) }}" class="btn btn-sm btn-success" title="Unduh PDF">
                                        <i class="bi bi-download"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="6" class="text-center">Tidak ada data surat keputusan</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection

@push('script')
<script>
    $(document).ready(function() {
        $('#tabelKeputusan').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Indonesian.json"
            }
        });
    });
</script>
@endpush
