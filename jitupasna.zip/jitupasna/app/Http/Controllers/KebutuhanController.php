<?php

namespace App\Http\Controllers;

use App\Models\Bencana;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class KebutuhanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Get all disasters with related data
        $bencanas = Bencana::with('kategori_bencana')
            ->orderBy('created_at', 'desc')
            ->get();

        return view('kebutuhan.index', compact('bencanas'));
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create($id)
    {
        $bencana = Bencana::with('kategori_bencana')->findOrFail($id);

        return view('kebutuhan.create', compact('bencana'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, $id)
    {
        // Basic validation
        $validated = $request->validate([
            'kebutuhan_material' => 'required|string',
            'kebutuhan_sdm' => 'required|string',
            'kebutuhan_dana' => 'required|numeric',
        ]);

        $bencana = Bencana::findOrFail($id);

        // Implementation will depend on your database structure
        // This is a placeholder until the model for Kebutuhan is created

        return redirect()->route('kebutuhan.index')->with('success', 'Data kebutuhan berhasil disimpan');
    }
    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $bencana = Bencana::with('kategori_bencana')->findOrFail($id);

        return view('kebutuhan.show', compact('bencana'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $bencana = Bencana::findOrFail($id);

        return view('kebutuhan.edit', compact('bencana'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Basic validation
        $validated = $request->validate([
            'kebutuhan_material' => 'required|string',
            'kebutuhan_sdm' => 'required|string',
            'kebutuhan_dana' => 'required|numeric',
        ]);

        $bencana = Bencana::findOrFail($id);

        // Implementation will depend on your database structure
        // This is a placeholder until the model for Kebutuhan is created

        return redirect()->route('kebutuhan.index')->with('success', 'Data kebutuhan berhasil diperbarui');
    }
}
