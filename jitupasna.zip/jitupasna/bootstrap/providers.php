<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\DomPdfServiceProvider::class,
    Barryvdh\DomPDF\ServiceProvider::class,
];
