<?php
require 'vendor/autoload.php';
require 'bootstrap/app.php';
$app = app();
$tables = $app->make('db')->select('SHOW TABLES');
print_r($tables);
?>
