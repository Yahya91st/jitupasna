

<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
            <h3>Input Kebutuhan Pascabencana</h3>
            <p class="text-subtitle text-muted">Form input kebutuhan pascabencana</p>
        </div>
        <div class="col-12 col-md-6 order-md-2 order-first">
            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-md-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('kebutuhan.index')); ?>">Kebutuhan</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Input</li>
                </ol>
            </nav>
        </div>
    </div>
</div>

<section class="section">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Detail Bencana</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="tanggal">Tanggal Kejadian</label>
                        <p><?php echo e(is_string($bencana->tanggal) ? $bencana->tanggal : $bencana->tanggal->format('d-m-Y')); ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="jenis_bencana">Jenis Bencana</label>
                        <p><?php echo e($bencana->jenis_bencana ?? ($bencana->kategori_bencana ? $bencana->kategori_bencana->nama_kategori : '-')); ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="kecamatan">Kecamatan</label>
                        <p><?php echo e($bencana->kecamatan ?? $bencana->kecamatan_id); ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="desa">Desa</label>
                        <p><?php echo e($bencana->desa ?? $bencana->desa_id); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Form Input Kebutuhan</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('kebutuhan.store', $bencana->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="kebutuhan_material">Kebutuhan Material</label>
                            <textarea class="form-control" id="kebutuhan_material" name="kebutuhan_material" rows="3" placeholder="Masukkan kebutuhan material"><?php echo e(old('kebutuhan_material')); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="kebutuhan_sdm">Kebutuhan SDM</label>
                            <textarea class="form-control" id="kebutuhan_sdm" name="kebutuhan_sdm" rows="3" placeholder="Masukkan kebutuhan SDM"><?php echo e(old('kebutuhan_sdm')); ?></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="kebutuhan_dana">Estimasi Kebutuhan Dana (Rp)</label>
                            <input type="number" class="form-control" id="kebutuhan_dana" name="kebutuhan_dana" placeholder="Masukkan estimasi kebutuhan dana" value="<?php echo e(old('kebutuhan_dana')); ?>">
                        </div>
                    </div>
                    <div class="col-md-12 d-flex justify-content-end mt-3">
                        <button type="submit" class="btn btn-primary me-1 mb-1">Simpan</button>
                        <a href="<?php echo e(route('kebutuhan.index')); ?>" class="btn btn-light-secondary me-1 mb-1">Batal</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\Semester 4\jitupasna new\jitupasna\resources\views/kebutuhan/create.blade.php ENDPATH**/ ?>