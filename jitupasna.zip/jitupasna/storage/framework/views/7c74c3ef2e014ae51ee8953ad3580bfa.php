

<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
            <h3>Detail Kebutuhan Pascabencana</h3>
            <p class="text-subtitle text-muted">Detail kebutuhan pascabencana</p>
        </div>
        <div class="col-12 col-md-6 order-md-2 order-first">
            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-md-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('kebutuhan.index')); ?>">Kebutuhan</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Detail</li>
                </ol>
            </nav>
        </div>
    </div>
</div>

<section class="section">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Detail Bencana</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="tanggal">Tanggal Kejadian</label>
                        <p><?php echo e(is_string($bencana->tanggal) ? $bencana->tanggal : $bencana->tanggal->format('d-m-Y')); ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="jenis_bencana">Jenis Bencana</label>
                        <p><?php echo e($bencana->jenis_bencana ?? ($bencana->kategori_bencana ? $bencana->kategori_bencana->nama_kategori : '-')); ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="kecamatan">Kecamatan</label>
                        <p><?php echo e($bencana->kecamatan ?? $bencana->kecamatan_id); ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="desa">Desa</label>
                        <p><?php echo e($bencana->desa ?? $bencana->desa_id); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h4 class="card-title">Data Kebutuhan</h4>
            <a href="<?php echo e(route('kebutuhan.create', $bencana->id)); ?>" class="btn btn-primary">
                <i data-feather="plus-circle"></i> Input Kebutuhan
            </a>
        </div>
        <div class="card-body">
            <!-- This is a placeholder. In a real implementation, you'd display actual kebutuhan data from a model -->
            <div class="alert alert-info">
                <p class="mb-0">Data kebutuhan untuk bencana ini belum tersedia.</p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Kuliah\Semester 4\jitupasna new\jitupasna\resources\views/kebutuhan/show.blade.php ENDPATH**/ ?>